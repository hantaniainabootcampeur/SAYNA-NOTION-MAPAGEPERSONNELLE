# EXEMPLE DE MA PAGE WEB

---

# 📜PLAN DU SITE

---

[recette de cuisine test](EXEMPLE%20DE%20MA%20PAGE%20WEB%20c920b4b07212456a96c767dee928618f/recette%20de%20cuisine%20test%2071950845c24b419fb06f7c61d795fea5.csv)

![https://images.unsplash.com/photo-1577106263724-2c8e03bfe9cf?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb](https://images.unsplash.com/photo-1577106263724-2c8e03bfe9cf?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb)

[recette de cocktail test](EXEMPLE%20DE%20MA%20PAGE%20WEB%20c920b4b07212456a96c767dee928618f/recette%20de%20cocktail%20test%20e476e1d13e104f10bbb02041f1ce421e.csv)

![https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb](https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb)

[sport et activités test](EXEMPLE%20DE%20MA%20PAGE%20WEB%20c920b4b07212456a96c767dee928618f/sport%20et%20activite%CC%81s%20test%20bf5fcdbf4984439baa4c31a2c22d6913.csv)

![https://images.unsplash.com/photo-1515025617920-e1e674b5033c?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb](https://images.unsplash.com/photo-1515025617920-e1e674b5033c?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb)

[musique et playlist](EXEMPLE%20DE%20MA%20PAGE%20WEB%20c920b4b07212456a96c767dee928618f/musique%20et%20playlist%20bbbcc1ee1ba74b00b79947e200ddb931.csv)

![https://images.unsplash.com/photo-1626539896924-b328af4ef01d?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb](https://images.unsplash.com/photo-1626539896924-b328af4ef01d?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb)

[évènements test](EXEMPLE%20DE%20MA%20PAGE%20WEB%20c920b4b07212456a96c767dee928618f/e%CC%81ve%CC%80nements%20test%20fd133e3df453439ea66c07d822e67d69.csv)

![https://images.unsplash.com/photo-1594629706083-67fd4ea4f0d5?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb](https://images.unsplash.com/photo-1594629706083-67fd4ea4f0d5?ixlib=rb-4.0.3&q=85&fm=jpg&crop=entropy&cs=srgb)

---

# 🎁RESSOURCES PARTAGEES

> *Alimenter par la communauté et mes recherches, voici le kit indispensable pour mener une vie équilibrer.*
> 

cuisine

[recette de cuisine test (1)](EXEMPLE%20DE%20MA%20PAGE%20WEB%20c920b4b07212456a96c767dee928618f/recette%20de%20cuisine%20test%20(1)%203d247e0dc80a4c108454e1f9048560b6.csv)

cocktail

activités

musique

---

# 🎉EVENEMENTS

Calendrier

---

![tableau.png](EXEMPLE%20DE%20MA%20PAGE%20WEB%20c920b4b07212456a96c767dee928618f/tableau.png)

![téléchargement.png](EXEMPLE%20DE%20MA%20PAGE%20WEB%20c920b4b07212456a96c767dee928618f/tlchargement.png)

<aside>
👽 *Ce projet peut être personnalisé à volonté. L’objectif est de garder la logique de créer des databases connectées entre elles, avec des indicateurs automatisés par l’intermédiaire de formules et autres propriétés. 

De plus, l’intégration d’autres outils tels que Tally et Google Forms permettent d’automatiser ou d’augmenter l’utilisation d’informations.*

</aside>

---